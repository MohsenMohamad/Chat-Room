﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace persistent_layer.Users
{
    public class Users
    {
        private static SqlConnection connect;
        private static string ConnectionString;
         
        public Users()
        {
            ConnectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = c:\users\adnan\source\repos\persistent_layer\persistent_layer\Database1.mdf; Integrated Security = True";
            connect = new SqlConnection(ConnectionString);
        }
        public void Registeruser(string id, string name) {
            string CMD = "INSERT INTO Users (Id,name) VALUES ({0},{1})";
            CMD = string.Format(CMD , id, name);
            using (SqlCommand cmd = new SqlCommand(CMD, connect))
            {

                connect.Open();
                connect.Close();
            }
        }


              
    }
}
